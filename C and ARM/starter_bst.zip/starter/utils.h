
#include <stdio.h>


int cmpr_float(void*, void*);
int cmpr_int(void*, void*);
void print_int(void*);
void print_float(void*);